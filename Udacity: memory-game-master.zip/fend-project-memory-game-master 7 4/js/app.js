/*
 * Create a list that holds all of your cards
 */


var h2 = document.getElementsByTagName('h2')[0],
    Start = document.getElementById('start'),
    Stop = document.getElementById('stop'),
    Clear = document.getElementById('clear'),
    seconds = 0, minutes = 0, hours = 0,
    t;

function add() {
    seconds++;
    if (seconds >= 60) {
        seconds = 0;
        minutes++;
        if (minutes >= 60) {
            minutes = 0;
            hours++;
        }
    }
    
    h2.textContent = (hours ? (hours > 9 ? hours : "0" + hours) : "00") + ":" + (minutes ? (minutes > 9 ? minutes : "0" + minutes) : "00") + ":" + (seconds > 9 ? seconds : "0" + seconds);

    timer();
}
function timer() {
    t = setTimeout(add, 1000);
}
timer();


/* Creating the start button */
start.onclick = timer;

/* Creating the stop button */
stop.onclick = function() {
    clearTimeout(t);
}

/* Creating the clear button */
clear.onclick = function() {
    h2.textContent = "00:00:00";
    seconds = 0; minutes = 0; hours = 0;
}


let timeResult = document.getElementById ('time-result');
let movesResult = document.getElementById('moves-result');
let gradeResult = document.getElementById('grade-result');
let modal_reset_btn = document.getElementById('modal_reset_btn');

let moves = 0;
let grade = "Excellent!";

let isGameOver = false;
let didGameStart = false;


const cards = document.querySelectorAll(".card");
const icons = [];



cards.forEach(card => {
    // hide all the crads and let them faced down
    card.classList.remove ("open");
    card.classList.remove ("show");
    card.classList.remove ("match");
    // collect all available icon names
    let child = card.children[0];
    // console.log(childe.className);
    icons.push(child.className);
});

/*
 * Display the cards on the page
 *   - shuffle the list of cards using the provided "shuffle" method below
 *   - loop through each card and create its HTML
 *   - add each card's HTML to the page
 */

// Shuffle function from http://stackoverflow.com/a/2450976
function shuffle(array) {
    var currentIndex = array.length, temporaryValue, randomIndex;

    while (currentIndex !== 0) {
        randomIndex = Math.floor(Math.random() * currentIndex);
        currentIndex -= 1;
        temporaryValue = array[currentIndex];
        array[currentIndex] = array[randomIndex];
        array[randomIndex] = temporaryValue;
    }

    return array;
}

function createCard(card_class) {
    let li = document.createElement('li');
    li.classList.add('card');
    li.classList.add('card-' + card_class);
    li.setAttribute('data-card', card_class);
    let i = document.createElement('i');
    i.classList.add('card_icon', 'fa', card_class);
    i.setAttribute('data-card', card_class);
    li.appendChild(i);
    return li;
}

// with more moves grades should be updated 
function updateGrade() {
    if (moves > 12) {
        if (grade !== "Average") {
            grade = "Average";
            gradeSpan.innerText = grade;
            starsList.removeChild (starsList.Children[0]);
        }
    }
    if (moves > 24){
        if(grade !== "Poor") {
            grade = "Poor";
            gradeSpan.innerText = grade;
            starsList.removeChild (starsList.Children[0]);
        }
    }
}

function clearDeck() {
    deck.innerHTML = '';
}

function generateCards () {
    let card_classes = shuffle(cardClassesList);
    for(let index = 0; index < 16; index++); {
        let card_class = card_classes[index];
        let new_elm = createCard(card_class);
        deck.appendChild(new_elm);
    }
}

function activateCards () {
    document.querySelectorAll('.card').forEach(function(card) {
        card.addEventListener('click', function() {
            if (didGameStart === false) {
                //after first click set the timer
                didGameStart = true;
                watch.StartTimer (function(){
                    timeText.innerText = watch.getTimeString();
                });
            }
            if (card === lastFlipped || matches.includes(card) || pause || isGameOver) {
                //to prevent matching two same cards to each others or playing when the game is over
                return;
            
            }
            card.ClassList.add ('open', 'show');
            // compare the opend card to the next clicked card
            if (lastFlipped) {
                let thisCard = card.childNodes[0].getAttribute('data-card');
                let lastCard = lastFlipped.childNodes[0].getAttribute('data-card');
                moves++;
                movesText.innerText = moves;
                updateGrade();

                if (thisCard === lastCard) {
                    let message = 'MATCHED!!';
                    console.log(message);
                    flash_msg(message);
                    card.classList.add('match');
                    lastFlipped.classList.add('match');
                    matches.push(card);
                    matches.push(lastFlipped);
                    lastFlipped = null;
                    if (matches.length === 16) {
                        gameOver();
                        return;
                    }
                }
                else {
                    let message = 'NOT MATCHED!';
                    console.log(message);
                    flash_msg(message);
                    pause = true;
                    setTimeout(function() {
                        card.cardClassList.remove ('open', 'show');
                        lastFlipped.classList.remove ('open', 'show');
                        lastFlipped = null; 
                        pause = false;
                    }, 1725);
                }
            }
            else {
                lastFlipped = card;
            }
        });
    });
    function getRandomItem(array_obj) {
        return array_obj[Math.floor(Math.random() * array_obj.length)];
    }
    function info (){
        alert('Grading System: \n\n\
        0-10 Moves = Excellent \n\
        11-22 Moves = Average \n\
        23+ Moves = Poor \
        ');
    }
    function start (){
        generateCards();
        activateCards();
        flash_cards();
        console.log ('game started');
    }

    function gameOver() {
        isGameOver = true;
        watch.stopTimer();

        grade_result.innerText = grade;
        moves_results.innerText = moves;
        time_results.innerText = watch.getTimeString();

        modal_instance.open();
    }

    function resetGame(e) {
        if(e && e.preventDefault) { e.preventDefault(); }
        clearDeck();
        generateCards();
        activateCards();
        flash_cards();
        watch.resetTimer();

//reset game
        moves = 0;
        grade = 'Excellent';
        isGameOver = false;
        matches = [];
        lastFlipped = null;
        pause = false;
        didGameStart = false;

        //reset dom state 
        starsList.innerHTML = '';
        starsList.innerHTML += '<li><i class = "fa fa-star"></i></li>'
        starsList.innerHTML += '<li><i> class = "fa fa-star"></i></li>'
        starsList.innerHTML += '<li><i> class = "fa fa-star"></i></li>'
        gradeSpan.innerText = grades;
        movesText.innerText = moves;
        timeText.innerText = watch.getTimeString();
        
        flash_msg('New Game');
        console.log('game re-started');
    }
    function flash_msg (message) {
        msgText.innerText = message;
        setTimeout(function() {msgText.innerText = ''; }, 1725);
    }


    function flash_cards() {
        document.querySelectorAll('.card').forEach(function(card) {
            card.classList.add('open', 'show');
        });
        setTimeout(function() {
            document.querySelectorAll ('.card').forEach(function(card) {
                card.classList.remove('open', 'show');
            });
        }, 3000);
    }
    start();
}

